/* global angular */

'use strict';

/* Controllers */
var indicatorsControllers = angular.module('indicatorsControllers', ['mainController']);

